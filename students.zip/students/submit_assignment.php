<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: login.html");
    exit();
}

$student_id = $_SESSION['user_id'];
$assignment_id = $_GET['id'];

// Get assignment details
$stmt = $conn->prepare("SELECT * FROM assignments WHERE id = ?");
$stmt->bind_param("i", $assignment_id);
$stmt->execute();
$assignment = $stmt->get_result()->fetch_assoc();

if (!$assignment) {
    header("Location: view_assignments.php");
    exit();
}

// Check if already submitted
$check_stmt = $conn->prepare("SELECT id FROM assignment_submissions WHERE assignment_id = ? AND student_id = ?");
$check_stmt->bind_param("ii", $assignment_id, $student_id);
$check_stmt->execute();
if ($check_stmt->get_result()->num_rows > 0) {
    header("Location: view_submission.php?id=" . $assignment_id);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $submission_text = $_POST['submission_text'];
    
    // Handle file upload
    $submission_file = null;
    if (isset($_FILES['submission_file']) && $_FILES['submission_file']['error'] == 0) {
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES["submission_file"]["name"], PATHINFO_EXTENSION));
        $file_name = uniqid() . '.' . $file_extension;
        $target_file = $target_dir . $file_name;
        
        if (move_uploaded_file($_FILES["submission_file"]["tmp_name"], $target_file)) {
            $submission_file = $target_file;
        }
    }
    
    $stmt = $conn->prepare("INSERT INTO assignment_submissions (assignment_id, student_id, submission_text, submission_file) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $assignment_id, $student_id, $submission_text, $submission_file);
    
    if ($stmt->execute()) {
        header("Location: view_submission.php?id=" . $assignment_id);
        exit();
    } else {
        $error = "Failed to submit assignment";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Submit Assignment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .assignment-details {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            height: 200px;
            resize: vertical;
        }
        input[type="file"] {
            margin-top: 5px;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .error {
            color: #f44336;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Submit Assignment</h2>
        
        <div class="assignment-details">
            <h3><?php echo htmlspecialchars($assignment['title']); ?></h3>
            <p><strong>Due Date:</strong> <?php echo date('d M Y', strtotime($assignment['due_date'])); ?></p>
            <p><strong>Description:</strong></p>
            <p><?php echo nl2br(htmlspecialchars($assignment['description'])); ?></p>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="" enctype="multipart/form-data">
            <div class="form-group">
                <label for="submission_text">Your Submission:</label>
                <textarea id="submission_text" name="submission_text" required></textarea>
            </div>
            
            <div class="form-group">
                <label for="submission_file">Upload File (Optional):</label>
                <input type="file" id="submission_file" name="submission_file">
            </div>
            
            <button type="submit">Submit Assignment</button>
        </form>
        
        <p><a href="view_assignments.php">Back to Assignments</a></p>
    </div>
</body>
</html> 