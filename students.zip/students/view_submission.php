<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$assignment_id = $_GET['id'];

// Get assignment details
$stmt = $conn->prepare("SELECT a.*, u.username as created_by_name 
                      FROM assignments a 
                      JOIN users u ON a.created_by = u.id 
                      WHERE a.id = ?");
$stmt->bind_param("i", $assignment_id);
$stmt->execute();
$assignment = $stmt->get_result()->fetch_assoc();

if (!$assignment) {
    header("Location: view_assignments.php");
    exit();
}

// Get submission details
if ($role == 'admin') {
    $sub_stmt = $conn->prepare("SELECT s.*, u.username as student_name 
                              FROM assignment_submissions s 
                              JOIN users u ON s.student_id = u.id 
                              WHERE s.assignment_id = ?");
    $sub_stmt->bind_param("i", $assignment_id);
} else {
    $sub_stmt = $conn->prepare("SELECT s.*, u.username as student_name 
                              FROM assignment_submissions s 
                              JOIN users u ON s.student_id = u.id 
                              WHERE s.assignment_id = ? AND s.student_id = ?");
    $sub_stmt->bind_param("ii", $assignment_id, $user_id);
}

$sub_stmt->execute();
$submissions = $sub_stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Submissions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .assignment-details {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .submission-card {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .submission-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .submission-text {
            margin: 15px 0;
            line-height: 1.5;
            white-space: pre-wrap;
        }
        .file-link {
            display: inline-block;
            padding: 5px 10px;
            background-color: #2196F3;
            color: white;
            text-decoration: none;
            border-radius: 3px;
            font-size: 14px;
        }
        .file-link:hover {
            background-color: #0b7dda;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .back-link:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Assignment Submissions</h2>
        
        <div class="assignment-details">
            <h3><?php echo htmlspecialchars($assignment['title']); ?></h3>
            <p><strong>Created by:</strong> <?php echo htmlspecialchars($assignment['created_by_name']); ?></p>
            <p><strong>Due Date:</strong> <?php echo date('d M Y', strtotime($assignment['due_date'])); ?></p>
            <p><strong>Description:</strong></p>
            <p><?php echo nl2br(htmlspecialchars($assignment['description'])); ?></p>
        </div>
        
        <?php if ($submissions->num_rows > 0): ?>
            <?php while ($submission = $submissions->fetch_assoc()): ?>
                <div class="submission-card">
                    <div class="submission-header">
                        <div>
                            <strong>Submitted by:</strong> <?php echo htmlspecialchars($submission['student_name']); ?>
                        </div>
                        <div>
                            <strong>Submitted on:</strong> <?php echo date('d M Y H:i', strtotime($submission['submitted_at'])); ?>
                        </div>
                    </div>
                    
                    <div class="submission-text">
                        <?php echo nl2br(htmlspecialchars($submission['submission_text'])); ?>
                    </div>
                    
                    <?php if ($submission['submission_file']): ?>
                        <p>
                            <a href="<?php echo htmlspecialchars($submission['submission_file']); ?>" class="file-link" target="_blank">
                                View Attached File
                            </a>
                        </p>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No submissions found.</p>
        <?php endif; ?>
        
        <a href="view_assignments.php" class="back-link">Back to Assignments</a>
    </div>
</body>
</html> 