<?php
session_start();
require_once 'db_connection.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $student_id = $_POST['student_id'];
            $subject = $_POST['subject'];
            $marks = $_POST['marks'];

            $stmt = $conn->prepare("INSERT INTO student_marks (student_id, subject, marks) VALUES (?, ?, ?)");
            $stmt->bind_param("isi", $student_id, $subject, $marks);
            $stmt->execute();
        } elseif ($_POST['action'] == 'update') {
            $id = $_POST['id'];
            $marks = $_POST['marks'];

            $stmt = $conn->prepare("UPDATE student_marks SET marks = ? WHERE id = ?");
            $stmt->bind_param("ii", $marks, $id);
            $stmt->execute();
        } elseif ($_POST['action'] == 'delete') {
            $id = $_POST['id'];

            $stmt = $conn->prepare("DELETE FROM student_marks WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
        }
    }
}

// Get all students
$students = $conn->query("SELECT id, username FROM users WHERE role = 'student'");

// Get all marks
$marks = $conn->query("SELECT sm.id, u.username, sm.subject, sm.marks 
                      FROM student_marks sm 
                      JOIN users u ON sm.student_id = u.id 
                      ORDER BY u.username, sm.subject");

// Get pending assignments count
$pending_assignments = $conn->query("SELECT COUNT(*) as count FROM assignments WHERE due_date >= CURDATE()")->fetch_assoc()['count'];

// Get today's attendance count
$today = date('Y-m-d');
$attendance = $conn->query("SELECT 
                            SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
                            COUNT(*) as total
                          FROM attendance 
                          WHERE date = '$today'")->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-card h3 {
            margin-top: 0;
            color: #333;
        }
        .stat-value {
            font-size: 24px;
            font-weight: bold;
            color: #4CAF50;
            margin: 10px 0;
        }
        .action-link {
            display: inline-block;
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .action-link:hover {
            background-color: #45a049;
        }
        .section {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .marks-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .marks-table th, .marks-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .marks-table th {
            background-color: #4CAF50;
            color: white;
        }
        .marks-table tr:hover {
            background-color: #f5f5f5;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .logout-btn {
            padding: 8px 16px;
            background-color: #f44336;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Admin Dashboard</h1>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>

        <div class="quick-stats">
            <div class="stat-card">
                <h3>Today's Attendance</h3>
                <div class="stat-value">
                    <?php 
                    if ($attendance['total'] > 0) {
                        echo round(($attendance['present'] / $attendance['total']) * 100) . '%';
                    } else {
                        echo '0%';
                    }
                    ?>
                </div>
                <p><?php echo $attendance['present'] ?? 0; ?> present out of <?php echo $attendance['total'] ?? 0; ?></p>
            </div>

            <div class="stat-card">
                <h3>Active Assignments</h3>
                <div class="stat-value"><?php echo $pending_assignments; ?></div>
                <a href="view_assignments.php" class="action-link">Manage Assignments</a>
            </div>

            <div class="stat-card">
                <h3>Quick Actions</h3>
                <p>
                    <a href="create_assignment.php" class="action-link">Create Assignment</a>
                </p>
            </div>
        </div>

        <div class="section">
            <div class="section-header">
                <h2>Manage Student Marks</h2>
            </div>

            <form method="POST" action="">
                <input type="hidden" name="action" value="add">
                <div class="form-group">
                    <label for="student_id">Student:</label>
                    <select name="student_id" required>
                        <?php while($student = $students->fetch_assoc()): ?>
                            <option value="<?php echo $student['id']; ?>"><?php echo htmlspecialchars($student['username']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="subject">Subject:</label>
                    <input type="text" name="subject" required>
                </div>
                <div class="form-group">
                    <label for="marks">Marks:</label>
                    <input type="number" name="marks" min="0" max="100" required>
                </div>
                <button type="submit">Add Marks</button>
            </form>

            <table class="marks-table">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Subject</th>
                        <th>Marks</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($mark = $marks->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($mark['username']); ?></td>
                            <td><?php echo htmlspecialchars($mark['subject']); ?></td>
                            <td><?php echo htmlspecialchars($mark['marks']); ?></td>
                            <td class="action-buttons">
                                <form method="POST" action="" style="display: inline;">
                                    <input type="hidden" name="action" value="update">
                                    <input type="hidden" name="id" value="<?php echo $mark['id']; ?>">
                                    <input type="number" name="marks" value="<?php echo $mark['marks']; ?>" min="0" max="100" style="width: 60px;">
                                    <button type="submit">Update</button>
                                </form>
                                <form method="POST" action="" style="display: inline;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?php echo $mark['id']; ?>">
                                    <button type="submit" style="background-color: #f44336;">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html> 