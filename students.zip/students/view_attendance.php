<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$student_id = $_SESSION['user_id'];

// Get attendance records
$stmt = $conn->prepare("SELECT date, status FROM attendance WHERE student_id = ? ORDER BY date DESC");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();

// Calculate attendance statistics
$total_days = $result->num_rows;
$present_days = 0;
$absent_days = 0;

while ($row = $result->fetch_assoc()) {
    if ($row['status'] == 'present') {
        $present_days++;
    } else {
        $absent_days++;
    }
}

$attendance_percentage = $total_days > 0 ? round(($present_days / $total_days) * 100, 2) : 0;

// Reset result pointer
$result->data_seek(0);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attendance History</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .stats {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .stat-item {
            text-align: center;
        }
        .stat-value {
            font-size: 24px;
            font-weight: bold;
            color: #4CAF50;
        }
        .attendance-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .attendance-table th, .attendance-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .attendance-table th {
            background-color: #4CAF50;
            color: white;
        }
        .attendance-table tr:hover {
            background-color: #f5f5f5;
        }
        .present {
            color: #4CAF50;
        }
        .absent {
            color: #f44336;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .back-link:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Attendance History</h2>
        
        <div class="stats">
            <div class="stat-item">
                <div class="stat-value"><?php echo $total_days; ?></div>
                <div>Total Days</div>
            </div>
            <div class="stat-item">
                <div class="stat-value"><?php echo $present_days; ?></div>
                <div>Present Days</div>
            </div>
            <div class="stat-item">
                <div class="stat-value"><?php echo $absent_days; ?></div>
                <div>Absent Days</div>
            </div>
            <div class="stat-item">
                <div class="stat-value"><?php echo $attendance_percentage; ?>%</div>
                <div>Attendance %</div>
            </div>
        </div>

        <table class="attendance-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo date('d M Y', strtotime($row['date'])); ?></td>
                        <td class="<?php echo $row['status']; ?>">
                            <?php echo ucfirst($row['status']); ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <a href="student_dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html> 