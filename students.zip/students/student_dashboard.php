<?php
session_start();
require_once 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Get student's marks
$stmt = $conn->prepare("SELECT subject, marks FROM student_marks WHERE student_id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

// Get today's attendance status
$today = date('Y-m-d');
$att_stmt = $conn->prepare("SELECT status FROM attendance WHERE student_id = ? AND date = ?");
$att_stmt->bind_param("is", $_SESSION['user_id'], $today);
$att_stmt->execute();
$attendance = $att_stmt->get_result()->fetch_assoc();

// Get pending assignments count
$assign_stmt = $conn->prepare("SELECT COUNT(*) as pending FROM assignments a 
                             LEFT JOIN assignment_submissions s 
                             ON a.id = s.assignment_id AND s.student_id = ?
                             WHERE s.id IS NULL AND a.due_date >= CURDATE()");
$assign_stmt->bind_param("i", $_SESSION['user_id']);
$assign_stmt->execute();
$pending_assignments = $assign_stmt->get_result()->fetch_assoc()['pending'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .action-card {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            text-align: center;
        }
        .action-card h3 {
            margin-top: 0;
            color: #333;
        }
        .action-card p {
            margin: 10px 0;
            color: #666;
        }
        .action-link {
            display: inline-block;
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 10px;
        }
        .action-link:hover {
            background-color: #45a049;
        }
        .marks-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .marks-table th, .marks-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .marks-table th {
            background-color: #4CAF50;
            color: white;
        }
        .marks-table tr:hover {
            background-color: #f5f5f5;
        }
        .logout-btn {
            padding: 8px 16px;
            background-color: #f44336;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
        .badge {
            display: inline-block;
            padding: 3px 7px;
            border-radius: 10px;
            font-size: 12px;
            font-weight: bold;
        }
        .badge-warning {
            background-color: #ffc107;
            color: #000;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></h1>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>

        <div class="quick-actions">
            <div class="action-card">
                <h3>Today's Attendance</h3>
                <?php if ($attendance): ?>
                    <p>Status: <?php echo ucfirst($attendance['status']); ?></p>
                    <a href="view_attendance.php" class="action-link">View History</a>
                <?php else: ?>
                    <p>Not marked yet</p>
                    <a href="mark_attendance.php" class="action-link">Mark Attendance</a>
                <?php endif; ?>
            </div>

            <div class="action-card">
                <h3>Assignments</h3>
                <p>
                    Pending: 
                    <?php if ($pending_assignments > 0): ?>
                        <span class="badge badge-warning"><?php echo $pending_assignments; ?></span>
                    <?php else: ?>
                        0
                    <?php endif; ?>
                </p>
                <a href="view_assignments.php" class="action-link">View Assignments</a>
            </div>

            <div class="action-card">
                <h3>Academic Progress</h3>
                <p>View your marks and progress</p>
                <a href="#marks-section" class="action-link">View Details</a>
            </div>
        </div>
        
        <div id="marks-section">
            <h2>Your Marks</h2>
            <table class="marks-table">
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Marks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['subject']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['marks']) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='2'>No marks available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html> 