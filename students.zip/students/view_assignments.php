<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Get assignments
if ($role == 'admin') {
    $stmt = $conn->prepare("SELECT a.*, u.username as created_by_name 
                          FROM assignments a 
                          JOIN users u ON a.created_by = u.id 
                          ORDER BY a.due_date DESC");
} else {
    $stmt = $conn->prepare("SELECT a.*, u.username as created_by_name, 
                          (SELECT COUNT(*) FROM assignment_submissions 
                           WHERE assignment_id = a.id AND student_id = ?) as submitted
                          FROM assignments a 
                          JOIN users u ON a.created_by = u.id 
                          ORDER BY a.due_date DESC");
    $stmt->bind_param("i", $user_id);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assignments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .assignment-card {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
            background-color: white;
        }
        .assignment-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .assignment-title {
            font-size: 20px;
            font-weight: bold;
            color: #333;
        }
        .assignment-meta {
            color: #666;
            font-size: 14px;
        }
        .assignment-description {
            margin: 15px 0;
            line-height: 1.5;
        }
        .assignment-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        .due-date {
            color: #666;
        }
        .status {
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
        }
        .pending {
            background-color: #fff3cd;
            color: #856404;
        }
        .submitted {
            background-color: #d4edda;
            color: #155724;
        }
        .overdue {
            background-color: #f8d7da;
            color: #721c24;
        }
        .action-button {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        .submit-btn {
            background-color: #4CAF50;
            color: white;
        }
        .submit-btn:hover {
            background-color: #45a049;
        }
        .view-btn {
            background-color: #2196F3;
            color: white;
        }
        .view-btn:hover {
            background-color: #0b7dda;
        }
        .create-btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .create-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Assignments</h2>
        
        <?php if ($role == 'admin'): ?>
            <a href="create_assignment.php" class="create-btn">Create New Assignment</a>
        <?php endif; ?>

        <?php while ($assignment = $result->fetch_assoc()): ?>
            <div class="assignment-card">
                <div class="assignment-header">
                    <div class="assignment-title"><?php echo htmlspecialchars($assignment['title']); ?></div>
                    <div class="assignment-meta">
                        Created by: <?php echo htmlspecialchars($assignment['created_by_name']); ?>
                    </div>
                </div>
                
                <div class="assignment-description">
                    <?php echo nl2br(htmlspecialchars($assignment['description'])); ?>
                </div>
                
                <div class="assignment-footer">
                    <div class="due-date">
                        Due Date: <?php echo date('d M Y', strtotime($assignment['due_date'])); ?>
                    </div>
                    
                    <?php if ($role == 'student'): ?>
                        <?php
                        $status = '';
                        $button_text = '';
                        $button_link = '';
                        
                        if ($assignment['submitted']) {
                            $status = 'submitted';
                            $button_text = 'View Submission';
                            $button_link = 'view_submission.php?id=' . $assignment['id'];
                        } else {
                            if (strtotime($assignment['due_date']) < time()) {
                                $status = 'overdue';
                            } else {
                                $status = 'pending';
                            }
                            $button_text = 'Submit Assignment';
                            $button_link = 'submit_assignment.php?id=' . $assignment['id'];
                        }
                        ?>
                        
                        <div class="status <?php echo $status; ?>">
                            <?php echo ucfirst($status); ?>
                        </div>
                        
                        <a href="<?php echo $button_link; ?>" class="action-button <?php echo $status == 'submitted' ? 'view-btn' : 'submit-btn'; ?>">
                            <?php echo $button_text; ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile; ?>
        
        <p><a href="<?php echo $role == 'admin' ? 'admin_dashboard.php' : 'student_dashboard.php'; ?>">Back to Dashboard</a></p>
    </div>
</body>
</html> 